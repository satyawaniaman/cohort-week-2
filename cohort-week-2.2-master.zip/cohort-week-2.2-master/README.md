week 2 of creating a http server usign express library in node.js
