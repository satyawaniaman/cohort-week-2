```
npm install
npm run dev
```

```
npm run deploy
```
