import './App.css'
import { Assignment1 } from './components/Assignment1'
import { Assignment2 } from './components/Assignment2'

function App() {
  return (
    <>
      {/* <Assignment1 /> */}
      <Assignment2 />
    </>
  )
}

export default App
